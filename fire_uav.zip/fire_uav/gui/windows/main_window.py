# mypy: ignore-errors
from __future__ import annotations

import json
import logging
import tempfile
import time
from pathlib import Path
from datetime import datetime
from typing import Callable, Final

import cv2
import httpx
import numpy as np
from numpy.typing import NDArray
from PySide6.QtCore import Property, QObject, QUrl, Signal, Slot, QTimer
from PySide6.QtGui import QColor, QImage, QPainter, QPen
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtQuick import QQuickImageProvider

import fire_uav.infrastructure.providers as deps
from fire_uav.config import settings
from fire_uav.core.protocol import MapBounds
from fire_uav.gui.map_providers import FoliumMapProvider, MapProvider, StaticImageMapProvider
from fire_uav.gui.viewmodels.detector_vm import DetectorVM
from fire_uav.gui.viewmodels.planner_vm import PlannerVM
from fire_uav.services.components.camera import CameraThread
from fire_uav.services.bus import Event, bus

_log: Final = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
#                            Video helpers
# --------------------------------------------------------------------------- #
class VideoFrameProvider(QQuickImageProvider):
    """Simple QML image provider that keeps last rendered frame."""

    def __init__(self) -> None:
        super().__init__(QQuickImageProvider.Image)
        self._image = QImage()

    def requestImage(self, _id, size, requestedSize):  # type: ignore[override]
        if not self._image.isNull():
            if size is not None:
                size.setWidth(self._image.width())
                size.setHeight(self._image.height())
            return self._image

        # fallback placeholder to avoid QML warnings
        placeholder = QImage(
            requestedSize.width() if requestedSize else 1280,
            requestedSize.height() if requestedSize else 720,
            QImage.Format.Format_ARGB32,
        )
        placeholder.fill(QColor("#0a111b"))
        return placeholder

    def set_image(self, image: QImage) -> None:
        self._image = image


class VideoBridge(QObject):
    """Stores last frame + bboxes and notifies QML to refresh the Image."""

    frameReady = Signal(str)

    def __init__(self, provider: VideoFrameProvider) -> None:
        super().__init__()
        self._provider = provider
        self._last_frame: NDArray[np.uint8] | None = None
        self._bboxes: list[tuple[int, int, int, int]] = []
        self._counter = 0

    @Slot(object)
    def set_bboxes(self, boxes: list[tuple[int, int, int, int]] | None) -> None:
        self._bboxes = boxes or []
        self._render()

    def update_frame(self, frame: NDArray[np.uint8]) -> None:
        self._last_frame = frame
        self._render()

    # ---------- internal ---------- #
    def _render(self) -> None:
        if self._last_frame is None:
            return

        h, w, _ = self._last_frame.shape
        img = QImage(self._last_frame.data, w, h, 3 * w, QImage.Format.Format_BGR888).copy()

        if self._bboxes:
            painter = QPainter(img)
            pen = QPen(QColor("#70e0ff"), 2)
            painter.setPen(pen)
            for x1, y1, x2, y2 in self._bboxes:
                painter.drawRect(x1, y1, x2 - x1, y2 - y1)
            painter.end()

        self._provider.set_image(img)
        self._counter += 1
        self.frameReady.emit(f"image://video/live?{self._counter}")


# --------------------------------------------------------------------------- #
#                             Logging bridge
# --------------------------------------------------------------------------- #
class QmlLogHandler(logging.Handler, QObject):
    message = Signal(str)

    def __init__(self) -> None:
        logging.Handler.__init__(self)
        QObject.__init__(self)
        self.setFormatter(logging.Formatter("%(asctime)s  %(levelname)-8s  %(message)s"))

    def emit(self, record: logging.LogRecord) -> None:  # noqa: D401
        try:
            self.message.emit(self.format(record))
        except Exception:  # noqa: BLE001
            pass


class MapBridge(QObject):
    """Generates Folium map with draw controls and bridges JS→Python via console logs."""

    urlChanged = Signal(QUrl)
    toastRequested = Signal(str)

    def __init__(self, vm: PlannerVM, provider: MapProvider | None = None) -> None:
        super().__init__()
        self._vm = vm
        cache_dir = Path(__file__).resolve().parents[2] / "data" / "cache" / "tiles"
        self._default_cache_dir = cache_dir
        self._provider: MapProvider = provider or self._select_provider()
        self._map_path: Path = Path(tempfile.gettempdir()) / "plan_map.html"
        self._token = 0
        self._last_render_progress: float | None = None
        self.render_map()

    # ----- properties exposed to QML ----- #
    @Property(QUrl, notify=urlChanged)
    def url(self) -> QUrl:
        url = QUrl.fromLocalFile(str(self._map_path))
        url.setQuery(f"v={self._token}")
        return url

    @Property(str, constant=True)
    def bridgeScript(self) -> str:
        return getattr(self._provider, "bridge_script", "")

    # ----- slots for QML ----- #
    @Slot()
    def render_map(self) -> None:
        path = self._vm.get_active_path()
        self._map_path = self._provider.render_map(path, self._token)
        self._token += 1
        try:
            self._last_render_progress = float(getattr(deps, "debug_flight_progress", 0.0))
        except Exception:
            self._last_render_progress = 0.0
        self.urlChanged.emit(self.url)

    @Slot(str)
    def handle_console(self, message: str) -> None:
        if message.startswith("PY_PATH "):
            gj = json.loads(message.split(" ", 1)[1])
            pts = [(lat, lon) for lon, lat in gj.get("coordinates", [])]
            self._vm.save_plan(pts)
            self._after_path_changed()
            self.toastRequested.emit("Path updated")
            return

        if message.startswith("PY_TARGET "):
            gj = json.loads(message.split(" ", 1)[1])
            coords = gj.get("coordinates") or []
            if len(coords) == 2:
                try:
                    lon, lat = coords
                    self._vm.set_debug_target(lat, lon)
                    self._vm.compute_orbit_preview()
                    self.render_map()
                    self.toastRequested.emit("Debug target set, orbit preview updated")
                except Exception as exc:  # noqa: BLE001
                    self.toastRequested.emit(f"Orbit preview error: {exc}")
            else:
                self._vm.clear_debug_target()
                self.render_map()
                self.toastRequested.emit("Debug target cleared")
            return

    @Slot()
    def generate_path(self) -> None:
        try:
            fn = self._vm.generate_path()
            rel = fn
            try:
                rel = fn.relative_to(fn.parents[1])
            except Exception:
                pass
            self.toastRequested.emit(f"Path saved -> {rel}")
        except Exception as exc:  # noqa: BLE001
            self.toastRequested.emit(str(exc))

    @Slot()
    def save_plan(self) -> None:
        try:
            fn = self._vm.export_qgc_plan(alt_m=120.0)
            self.toastRequested.emit(f"Mission saved → {fn.relative_to(fn.parents[1])}")
        except Exception as exc:  # noqa: BLE001
            self.toastRequested.emit(str(exc))

    @Slot(str)
    def import_geojson(self, fn: str) -> None:
        if not fn:
            return
        try:
            self._vm.import_geojson(Path(fn))
            self._after_path_changed()
            self.toastRequested.emit("Polyline imported")
        except Exception as exc:  # noqa: BLE001
            self.toastRequested.emit(f"Error: {exc}")

    @Slot(str)
    def import_kml(self, fn: str) -> None:
        if not fn:
            return
        try:
            pts = self._parse_kml(Path(fn))
            self._vm.save_plan(pts)
            self._after_path_changed()
            self.toastRequested.emit("KML imported")
        except Exception as exc:  # noqa: BLE001
            self.toastRequested.emit(f"Error: {exc}")

    @Slot(str, bool, str)
    def set_provider(self, provider: str, offline: bool, cache_dir: str = "") -> None:
        provider = (provider or "osm").lower()
        cd = Path(cache_dir) if cache_dir else self._default_cache_dir
        if provider == "static_image":
            static_provider = self._build_static_provider()
            if static_provider:
                self._provider = static_provider
                self.render_map()
            else:
                _log.warning("Static image provider unavailable; keeping current map provider")
            return
        if isinstance(self._provider, StaticImageMapProvider):
            self._provider = FoliumMapProvider(provider=provider, offline=offline, cache_dir=cd)
            self.render_map()
            return
        self._provider.set_provider(provider, offline=offline, cache_dir=cd)
        self.render_map()

    @Slot()
    def recomputeOrbitPreview(self) -> None:
        """Rebuild orbit preview around current debug target and refresh the map."""
        if deps.debug_target is None:
            self.toastRequested.emit("Set a debug target marker first")
            return
        if not self._vm.get_path():
            self.toastRequested.emit("Draw a main route first")
            return
        try:
            self._vm.compute_orbit_preview()
            self.render_map()
            if deps.debug_orbit_path:
                self.toastRequested.emit("Orbit preview recomputed")
            else:
                self.toastRequested.emit("Orbit preview unavailable (energy/route?)")
        except Exception as exc:  # noqa: BLE001
            self.toastRequested.emit(f"Orbit preview error: {exc}")

    @Slot()
    def clearDebugTarget(self) -> None:
        """Clear debug target marker and orbit overlay."""
        self._vm.clear_debug_target()
        self.render_map()
        self.toastRequested.emit("Debug target cleared")

    @Slot()
    def refresh_drone(self) -> None:
        """Rerender map if drone progress changed enough to matter."""
        try:
            prog = float(getattr(deps, "debug_flight_progress", 0.0))
        except Exception:
            prog = 0.0
        if self._last_render_progress is None or abs(prog - self._last_render_progress) >= 0.02:
            self.render_map()

    # ----- helpers ----- #
    def _parse_kml(self, fn: Path) -> list[tuple[float, float]]:
        text = fn.read_text(encoding="utf-8", errors="ignore")
        if "<coordinates" not in text:
            raise RuntimeError("Coordinates not found in KML")
        coords_block = (
            text.split("<coordinates", 1)[1].split(">", 1)[1].split("</coordinates>", 1)[0]
        )
        pts: list[tuple[float, float]] = []
        for raw in coords_block.strip().replace("\n", " ").split():
            parts = raw.split(",")
            if len(parts) < 2:
                continue
            lon, lat = float(parts[0]), float(parts[1])
            pts.append((lat, lon))
        if not pts:
            raise RuntimeError("No valid points in KML")
        return pts

    def _after_path_changed(self) -> None:
        """Reset sim position and rebuild orbit preview if needed after path edits."""
        deps.debug_flight_progress = 0.0
        if deps.debug_target:
            try:
                self._vm.compute_orbit_preview()
            except Exception:
                pass
        self.render_map()

    def _select_provider(self) -> MapProvider:
        provider = str(getattr(settings, "map_provider", "osm") or "osm").lower()
        if provider == "static_image":
            static_provider = self._build_static_provider()
            if static_provider:
                return static_provider
            _log.warning("Static image provider requested but unavailable; falling back to OSM")
        return FoliumMapProvider(cache_dir=self._default_cache_dir)

    def _fetch_snapshot_info(self) -> tuple[str, MapBounds] | None:
        base_url = str(getattr(settings, "visualizer_url", "http://127.0.0.1:8000")).rstrip("/")
        uav_id = getattr(settings, "uav_id", None) or "uav"
        url = f"{base_url}/api/v1/map_snapshot/{uav_id}"
        try:
            resp = httpx.get(url, timeout=1.0)
            if resp.status_code == 404:
                _log.warning("Map snapshot not found for UAV %s at %s", uav_id, url)
                return None
            resp.raise_for_status()
            payload = resp.json()
        except Exception as exc:  # noqa: BLE001
            _log.warning("Failed to fetch map snapshot from %s: %s", url, exc)
            return None
        image_path = payload.get("image_path")
        bounds_raw = payload.get("bounds")
        if not image_path or not bounds_raw:
            _log.warning("Map snapshot payload missing image_path or bounds")
            return None
        try:
            bounds = bounds_raw if isinstance(bounds_raw, MapBounds) else MapBounds(**bounds_raw)
        except Exception:  # noqa: BLE001
            _log.warning("Map snapshot bounds invalid")
            return None
        return str(image_path), bounds

    def _build_static_provider(self) -> StaticImageMapProvider | None:
        image_path = getattr(settings, "static_map_image_path", None)
        bounds = getattr(settings, "static_map_bounds", None)
        if not image_path or not bounds:
            fetched = self._fetch_snapshot_info()
            if fetched:
                image_path, bounds = fetched
            else:
                _log.warning("Static map config missing image_path or bounds")
                return None
        if isinstance(bounds, dict):
            try:
                bounds = MapBounds(**bounds)
            except Exception:
                _log.warning("Static map bounds invalid")
                return None
        if not isinstance(bounds, MapBounds):
            _log.warning("Static map bounds invalid")
            return None
        if bounds.lat_min >= bounds.lat_max or bounds.lon_min >= bounds.lon_max:
            _log.warning("Static map bounds invalid: min must be < max")
            return None
        image_path = Path(str(image_path)).expanduser()
        if not image_path.exists():
            _log.warning("Static map image not found at %s", image_path)
            return None
        return StaticImageMapProvider(image_path=str(image_path), bounds=bounds)


# --------------------------------------------------------------------------- #
#                             App controller (QML-facing)
# --------------------------------------------------------------------------- #
class AppController(QObject):
    toastRequested = Signal(str)
    objectNotificationReceived = Signal(str, int, float, str, object)
    frameReady = Signal(str)
    mapUrlChanged = Signal(QUrl)
    logsChanged = Signal()
    confidenceChanged = Signal()
    detectorRunningChanged = Signal()
    cameraAvailableChanged = Signal()
    statsChanged = Signal()
    debugModeChanged = Signal()

    def __init__(
        self,
        det_vm: DetectorVM,
        map_bridge: MapBridge,
        video_bridge: VideoBridge,
        camera_available: bool,
        camera_switcher: Callable[[], bool] | None = None,
    ) -> None:
        super().__init__()
        self.det_vm = det_vm
        self.map_bridge = map_bridge
        self.video_bridge = video_bridge
        self._camera_switcher = camera_switcher

        self._logs: list[str] = []
        self._confidence = getattr(settings, "yolo_conf", 0.25)
        self._detector_running = False
        self._camera_available = camera_available
        self._fps = 0.0
        self._latency_ms = 0.0
        self._bus_alive = False
        self._detection_conf = 0.0
        self._last_frame_ts: float | None = None
        self._last_detection_ts: float | None = None
        self._ground_station_enabled = bool(getattr(settings, "ground_station_enabled", False))
        self._det_json_path = Path(getattr(settings, "output_root", Path("data/outputs"))) / (
            "detections.jsonl"
        )
        self._log_history_path = (
            Path(__file__).resolve().parents[3] / "data" / "artifacts" / "logs" / "fire_uav_debug.log"
        )
        self._plan_vm = map_bridge._vm  # internal access for debug helpers
        self._debug_flight_enabled = bool(deps.debug_flight_enabled)
        self._last_flight_tick_ts: float | None = None
        self._flight_speed_per_sec = 0.05  # fraction of path per second
        self._tile_cache_dir = Path(__file__).resolve().parents[2] / "data" / "cache" / "tiles"
        self._flight_timer: QTimer | None = QTimer(self)
        self._flight_timer.setInterval(400)
        self._flight_timer.timeout.connect(self._on_debug_flight_tick)
        if self._debug_flight_enabled:
            self._last_flight_tick_ts = time.perf_counter()
            self._flight_timer.start()

        # wire signals
        self.det_vm.detection.connect(self._on_detections)
        self.det_vm.bboxes.connect(self.video_bridge.set_bboxes)
        self.video_bridge.frameReady.connect(self.frameReady)
        self.map_bridge.urlChanged.connect(self.mapUrlChanged)
        self.map_bridge.toastRequested.connect(self.toastRequested)

        # logging to QML
        self._log_handler = QmlLogHandler()
        self._log_handler.setLevel(logging.DEBUG)
        self._log_handler.message.connect(self._append_log)
        root = logging.getLogger()
        root.addHandler(self._log_handler)
        self._load_log_history()
        bus.subscribe(Event.OBJECT_CONFIRMED_UI, self._on_object_confirmed)

    # ---------- properties ---------- #
    @Property("QStringList", notify=logsChanged)
    def logs(self) -> list[str]:
        return self._logs

    @Property(float, notify=confidenceChanged)
    def confidence(self) -> float:
        return self._confidence

    @Property(bool, notify=detectorRunningChanged)
    def detectorRunning(self) -> bool:
        return self._detector_running

    @Property(bool, notify=cameraAvailableChanged)
    def cameraAvailable(self) -> bool:
        return self._camera_available

    @Property(QUrl, notify=mapUrlChanged)
    def mapUrl(self) -> QUrl:
        return self.map_bridge.url

    @Property(str, constant=True)
    def mapBridgeScript(self) -> str:
        return self.map_bridge.bridgeScript

    @Property(float, notify=statsChanged)
    def fps(self) -> float:
        return self._fps

    @Property(float, notify=statsChanged)
    def latencyMs(self) -> float:
        return self._latency_ms

    @Property(float, notify=statsChanged)
    def detectionConfidence(self) -> float:
        return self._detection_conf

    @Property(bool, notify=statsChanged)
    def busAlive(self) -> bool:
        return self._bus_alive

    @Property(bool, notify=statsChanged)
    def groundStationEnabled(self) -> bool:
        return self._ground_station_enabled

    @Property(float, notify=statsChanged)
    def debugFlightProgress(self) -> float:
        return float(getattr(deps, "debug_flight_progress", 0.0))

    @Property(bool, notify=debugModeChanged)
    def debugMode(self) -> bool:
        return self._debug_flight_enabled

    @Property(str, constant=True)
    def tileCacheDir(self) -> str:
        return str(self._tile_cache_dir)

    # ---------- slots ---------- #
    @Slot()
    def cycleCamera(self) -> None:
        if self._camera_switcher is None:
            return
        self._camera_switcher()

    @Slot()
    def startDetector(self) -> None:
        self.det_vm.start()
        self._detector_running = True
        self.detectorRunningChanged.emit()

    @Slot()
    def stopDetector(self) -> None:
        self.det_vm.stop()
        self._detector_running = False
        self.detectorRunningChanged.emit()

    @Slot(float)
    def setConfidence(self, value: float) -> None:
        self._confidence = float(value)
        self.det_vm.set_conf(self._confidence)
        self.confidenceChanged.emit()

    @Slot(str)
    def handleMapConsole(self, message: str) -> None:
        self.map_bridge.handle_console(message)

    @Slot()
    def regenerateMap(self) -> None:
        self.map_bridge.render_map()

    @Slot()
    def generatePath(self) -> None:
        self.map_bridge.generate_path()

    @Slot()
    def savePlan(self) -> None:
        self.map_bridge.save_plan()

    @Slot(str)
    def importGeoJson(self, filename: str) -> None:
        self.map_bridge.import_geojson(filename)

    @Slot(str)
    def importKml(self, filename: str) -> None:
        self.map_bridge.import_kml(filename)

    @Slot(str, bool, str)
    def setMapProvider(self, provider: str, offline: bool, cacheDir: str = "") -> None:
        self.map_bridge.set_provider(provider, offline=offline, cache_dir=cacheDir or None)

    @Slot()
    def startFlightDebugMode(self) -> None:
        self._debug_flight_enabled = True
        deps.debug_flight_enabled = True
        if self._flight_timer is not None:
            self._flight_timer.start()
        self._last_flight_tick_ts = time.perf_counter()
        try:
            self.map_bridge.refresh_drone()
        except Exception:
            pass
        self.toastRequested.emit("Flight debug mode ON")
        self.debugModeChanged.emit()
        self.statsChanged.emit()

    @Slot()
    def stopFlightDebugMode(self) -> None:
        self._debug_flight_enabled = False
        deps.debug_flight_enabled = False
        if self._flight_timer is not None:
            self._flight_timer.stop()
        self._last_flight_tick_ts = None
        self.toastRequested.emit("Flight debug mode OFF")
        self.debugModeChanged.emit()
        self.statsChanged.emit()

    @Slot()
    def resetFlightDebugProgress(self) -> None:
        deps.debug_flight_progress = 0.0
        self.toastRequested.emit("Flight debug loop reset to start")
        self.statsChanged.emit()

    @Slot()
    def orbitTarget(self) -> None:
        if not self._plan_vm.get_path():
            self.toastRequested.emit("Draw/generate a route first")
            return
        self.map_bridge.generate_path()
        self.map_bridge.recomputeOrbitPreview()

    @Slot()
    def clearDebugTarget(self) -> None:
        self.map_bridge.clearDebugTarget()

    @Slot()
    def rebuildRoute(self) -> None:
        try:
            self._plan_vm.rebuild_route_from_current_geom(None)
            self.map_bridge.render_map()
            self.toastRequested.emit("Route rebuild triggered (debug stub)")
        except Exception as exc:  # noqa: BLE001
            self.toastRequested.emit(str(exc))

    @Slot()
    def recomputeOrbitPreview(self) -> None:
        self.map_bridge.recomputeOrbitPreview()

    @Slot(str)
    def showToast(self, message: str) -> None:
        self.toastRequested.emit(message or "Debug notification")

    # ---------- helpers ---------- #
    def on_frame(self, frame: NDArray[np.uint8]) -> None:
        now = time.perf_counter()
        if self._last_frame_ts is not None:
            dt = now - self._last_frame_ts
            if dt > 0:
                inst_fps = 1.0 / dt
                self._fps = 0.85 * self._fps + 0.15 * inst_fps if self._fps else inst_fps
        self._last_frame_ts = now
        self._update_stats()
        self.video_bridge.update_frame(frame)

    def set_camera_available(self, flag: bool) -> None:
        self._camera_available = flag
        self.cameraAvailableChanged.emit()

    def _on_debug_flight_tick(self) -> None:
        if not self._debug_flight_enabled:
            return
        path = self._plan_vm.get_active_path() if self._plan_vm is not None else []
        if not path:
            return
        now = time.perf_counter()
        dt = 0.0
        if self._last_flight_tick_ts is not None:
            dt = max(0.0, now - self._last_flight_tick_ts)
        else:
            dt = self._flight_timer.interval() / 1000.0 if self._flight_timer else 0.0
        self._last_flight_tick_ts = now
        deps.debug_flight_progress = (deps.debug_flight_progress + self._flight_speed_per_sec * dt) % 1.0
        self.statsChanged.emit()
        try:
            self.map_bridge.refresh_drone()
        except Exception:
            pass

    def _on_detections(self, dets) -> None:  # noqa: ANN001
        det_list = getattr(dets, "detections", [])
        if not det_list:
            self._detection_conf = 0.0
            self._last_detection_ts = None
            self._update_stats()
            return
        best_conf = max(getattr(d, "score", getattr(d, "confidence", 0.0)) for d in det_list)
        bbox = getattr(det_list[0], "bbox", None)
        if bbox is None and all(hasattr(det_list[0], k) for k in ("x1", "y1", "x2", "y2")):
            bbox = (
                getattr(det_list[0], "x1"),
                getattr(det_list[0], "y1"),
                getattr(det_list[0], "x2"),
                getattr(det_list[0], "y2"),
            )
        stable_count = getattr(self.det_vm, "last_stable_count", 0)
        stable_conf = getattr(self.det_vm, "last_stable_conf", 0.0)
        eff_conf = stable_conf if stable_count > 0 else best_conf
        self._detection_conf = eff_conf
        _log.info(
            "GUI detection event: raw=%d best=%.2f stable=%d stable_conf=%.2f bbox=%s",
            len(det_list),
            best_conf,
            stable_count,
            stable_conf,
            bbox,
        )
        if stable_count > 0:
            self.toastRequested.emit(f"Confirmed: {stable_count} (avg {stable_conf:.2f})")
        else:
            self.toastRequested.emit(f"Detections: {len(det_list)} (best {best_conf:.2f})")
        self._log_detection_event(det_list, eff_conf, bbox)

        now = time.perf_counter()
        self._last_detection_ts = now
        if self._last_frame_ts is not None:
            self._latency_ms = max(0.0, (now - self._last_frame_ts) * 1000)
        self._update_stats()

    def _append_log(self, line: str) -> None:
        self._logs.append(line)
        self._trim_logs()
        self.logsChanged.emit()

    def _on_object_confirmed(self, payload: object) -> None:
        if not isinstance(payload, dict):
            return
        obj_id = str(payload.get("object_id", ""))
        cls_id = int(payload.get("class_id", -1))
        conf = float(payload.get("confidence", 0.0))
        track_id = payload.get("track_id")
        track_str = f", track {track_id}" if track_id is not None else ""
        msg = f"Object {obj_id} (class {cls_id}{track_str}, conf {conf:.2f}) detected"
        self.objectNotificationReceived.emit(obj_id, cls_id, conf, msg, track_id)

    def _update_stats(self) -> None:
        now = time.perf_counter()
        if self._last_detection_ts is not None and (now - self._last_detection_ts) > 2.0:
            self._detection_conf = 0.0
        bus_alive = self._last_detection_ts is not None and (now - self._last_detection_ts) < 2.0
        if bus_alive != self._bus_alive:
            self._bus_alive = bus_alive
        self.statsChanged.emit()

    def _trim_logs(self) -> None:
        if len(self._logs) > 400:
            self._logs = self._logs[-400:]

    def _load_log_history(self, limit: int = 200) -> None:
        try:
            if not self._log_history_path.exists():
                return
            lines = self._log_history_path.read_text(encoding="utf-8", errors="ignore").splitlines()
            if limit:
                lines = lines[-limit:]
            self._logs.extend(lines)
            self._trim_logs()
            if lines:
                self.logsChanged.emit()
        except Exception:  # noqa: BLE001
            _log.exception("Failed to preload log history")

    # ---------- detection logging helpers ---------- #
    def _log_detection_event(
        self, detections: list[object], best_conf: float, bbox: tuple[int, int, int, int] | None
    ) -> None:
        classes = [
            int(getattr(d, "class_id", getattr(d, "cls", -1)))
            for d in detections
            if hasattr(d, "class_id") or hasattr(d, "cls")
        ]
        payload = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "count": len(detections),
            "best_confidence": round(float(best_conf), 4),
            "best_bbox": list(bbox) if bbox else None,
            "classes": classes,
            "detections": [self._serialize_detection(d) for d in detections],
        }
        _log.info(
            "Detection summary | count=%d best=%.2f classes=%s bbox=%s",
            len(detections),
            best_conf,
            classes or "n/a",
            bbox,
        )
        _log.info("Detection JSON %s", json.dumps(payload, ensure_ascii=False))
        self._write_detection_json(payload)

    def _serialize_detection(self, det: object) -> dict[str, object]:
        bbox = getattr(det, "bbox", None)
        if bbox is None and all(hasattr(det, k) for k in ("x1", "y1", "x2", "y2")):
            bbox = (
                getattr(det, "x1"),
                getattr(det, "y1"),
                getattr(det, "x2"),
                getattr(det, "y2"),
            )
        ts = getattr(det, "timestamp", None)
        ts_iso = None
        if hasattr(ts, "isoformat"):
            try:
                ts_iso = ts.isoformat()
            except Exception:  # noqa: BLE001
                ts_iso = None
        return {
            "class_id": getattr(det, "class_id", getattr(det, "cls", None)),
            "confidence": float(getattr(det, "confidence", getattr(det, "score", 0.0))),
            "bbox": list(bbox) if bbox else None,
            "camera_id": getattr(det, "camera_id", None),
            "timestamp": ts_iso,
        }

    def _write_detection_json(self, payload: dict[str, object]) -> None:
        try:
            self._det_json_path.parent.mkdir(parents=True, exist_ok=True)
            with self._det_json_path.open("a", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False)
                fh.write("\n")
        except Exception:  # noqa: BLE001
            _log.exception("Failed to write detection JSON")


# --------------------------------------------------------------------------- #
#                               MainWindow facade
# --------------------------------------------------------------------------- #
class MainWindow(QObject):
    """QML-driven UI facade that keeps the existing lifecycle wiring."""

    def __init__(self) -> None:
        super().__init__()
        self.det_vm = DetectorVM()
        self.plan_vm = PlannerVM()
        self._frame_q = deps.frame_queue
        self._cam_fps = getattr(settings, "camera_fps", 30)
        self._camera_index = 0
        self._camera_candidates: list[int] = self._probe_cameras()

        # Optional camera/detector threads
        try:
            self.cam_thr = deps.get_camera()
            self.det_thr = deps.get_detector()
            self._have_camera = True
            self._camera_index = getattr(self.cam_thr, "index", 0)
            if self._camera_index not in self._camera_candidates:
                self._camera_candidates.insert(0, self._camera_index)
            self.cam_thr.frame.connect(self._on_frame)
            self.cam_thr.error.connect(lambda msg: self.app.toastRequested.emit(msg))
        except RuntimeError:
            self.cam_thr = None
            self.det_thr = None
            self._have_camera = False

        # Register components before QML triggers APP_START so start_all() sees them.
        deps.get_lifecycle().register(self.cam_thr, self.det_thr)

        # Bridges exposed to QML
        self._video_provider = VideoFrameProvider()
        self._video_bridge = VideoBridge(self._video_provider)
        self._map_bridge = MapBridge(self.plan_vm)
        self.app = AppController(
            self.det_vm,
            self._map_bridge,
            self._video_bridge,
            camera_available=self._have_camera,
            camera_switcher=self._cycle_camera,
        )

        # QML engine + context
        self._engine = QQmlApplicationEngine()
        self._engine.addImageProvider("video", self._video_provider)
        self._engine.rootContext().setContextProperty("app", self.app)

        qml_path = Path(__file__).resolve().parents[1] / "qml" / "main.qml"
        _log.info("Loading QML UI from %s", qml_path)
        self._engine.load(QUrl.fromLocalFile(str(qml_path)))
        if not self._engine.rootObjects():
            raise RuntimeError("Failed to load QML UI")
        self._window = self._engine.rootObjects()[0]

    # ---------- facade API ---------- #
    def show(self) -> None:
        if self._window is not None:
            self._window.show()

    # ---------- slots from threads ---------- #
    def _on_frame(self, frame: NDArray[np.uint8]) -> None:
        if self._frame_q is not None:
            try:
                self._frame_q.put_nowait(frame)
            except Exception:
                pass
        self.app.on_frame(frame)

    # ---------- camera helpers ---------- #
    def _probe_cameras(self, limit: int = 5) -> list[int]:
        found: list[int] = []
        for idx in range(limit):
            cap = cv2.VideoCapture(idx)
            if cap.isOpened():
                found.append(idx)
            cap.release()
        return found

    def _camera_available(self, index: int) -> bool:
        cap = cv2.VideoCapture(index)
        ok = cap.isOpened()
        cap.release()
        return ok

    def _cycle_camera(self) -> bool:
        # Refresh candidate list each time to catch hotplug devices.
        self._camera_candidates = self._probe_cameras()
        if len(self._camera_candidates) <= 1:
            self.app.toastRequested.emit("No alternate camera found")
            return False

        current = (
            self._camera_index
            if self._camera_index in self._camera_candidates
            else self._camera_candidates[0]
        )
        next_idx = self._camera_candidates[
            (self._camera_candidates.index(current) + 1) % len(self._camera_candidates)
        ]
        if next_idx == current and len(self._camera_candidates) == 1:
            self.app.toastRequested.emit("No alternate camera found")
            return False

        return self._switch_camera(next_idx)

    def _switch_camera(self, index: int) -> bool:
        if not self._camera_available(index):
            self._have_camera = False
            self.app.set_camera_available(False)
            self.app.toastRequested.emit(f"Camera #{index} is not available")
            return False

        old_cam = getattr(self, "cam_thr", None)
        if old_cam is not None:
            try:
                old_cam.stop()
                old_cam.join(timeout=2.0)
            except Exception:  # noqa: BLE001
                pass

        try:
            new_cam = CameraThread(index=index, fps=self._cam_fps, out_queue=self._frame_q)
        except Exception as exc:  # noqa: BLE001
            self.cam_thr = None
            self._have_camera = False
            self.app.set_camera_available(False)
            self.app.toastRequested.emit(f"Failed to init camera #{index}: {exc}")
            return False

        new_cam.frame.connect(self._on_frame)
        new_cam.error.connect(lambda msg: self.app.toastRequested.emit(msg))
        deps.get_lifecycle().register(new_cam)
        new_cam.start()

        self.cam_thr = new_cam
        self._camera_index = index
        self._have_camera = True
        self.app.set_camera_available(True)
        self.app.toastRequested.emit(f"Camera switched to #{index}")
        return True
