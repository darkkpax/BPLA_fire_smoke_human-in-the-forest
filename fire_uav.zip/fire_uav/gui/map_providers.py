# mypy: ignore-errors
from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Protocol, runtime_checkable

import folium
from folium.plugins import Draw
import fire_uav.infrastructure.providers as deps
from fire_uav.core.protocol import MapBounds
from fire_uav.module_core.geometry import interpolate_path_point


@runtime_checkable
class MapProvider(Protocol):
    """Protocol for interchangeable map backends."""

    def render_map(self, path: list[tuple[float, float]], token: int) -> Path: ...
    @property
    def bridge_script(self) -> str: ...
    def set_provider(self, provider: str, *, offline: bool, cache_dir: Path | None) -> None: ...


class FoliumMapProvider:
    """
    Leaflet/Folium map provider with tile caching/offline toggle and provider switch.
    """

    TILESETS: dict[str, tuple[str, str]] = {
        "osm": ("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", "OpenStreetMap"),
        "terrain": (
            "https://stamen-tiles.a.ssl.fastly.net/terrain/{z}/{x}/{y}.jpg",
            "Stamen Terrain",
        ),
        "toner": ("https://stamen-tiles.a.ssl.fastly.net/toner/{z}/{x}/{y}.png", "Stamen Toner"),
        "sat": (
            "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
            "Esri World Imagery",
        ),
    }

    _BRIDGE_JS = """\
(() => {
  if (!window.L) { console.error('Leaflet failed to load'); return; }
  const map = Object.values(window).find(v => v instanceof L.Map);
  if (!map) { console.error('Map instance not found'); return; }

  function sendPath(gj) { console.log('PY_PATH ' + JSON.stringify(gj)); }
  function sendTarget(gj) { console.log('PY_TARGET ' + JSON.stringify(gj)); }

  map.on(L.Draw.Event.CREATED, e => {
      if (e.layerType === 'polyline') {
          sendPath(e.layer.toGeoJSON().geometry);
      } else if (e.layerType === 'marker') {
          sendTarget(e.layer.toGeoJSON().geometry);
      }
  });

  map.on(L.Draw.Event.EDITED, e => {
      e.layers.eachLayer(l => {
          if (l instanceof L.Polyline) {
              sendPath(l.toGeoJSON().geometry);
          } else if (l instanceof L.Marker) {
              sendTarget(l.toGeoJSON().geometry);
          }
      });
  });

  map.on(L.Draw.Event.DELETED, e => {
      let clearedPath = false;
      e.layers.eachLayer(l => {
          if (l instanceof L.Polyline) {
              clearedPath = true;
          } else if (l instanceof L.Marker) {
              sendTarget({type:'Point', coordinates:[]});
          }
      });
      if (clearedPath) {
          sendPath({type:'LineString', coordinates:[]});
      }
  });

  const attr = document.querySelector('.leaflet-control-attribution');
  if (map.attributionControl) map.attributionControl.remove();
  if (attr) attr.remove();
})();"""

    def __init__(
        self,
        provider: str = "osm",
        *,
        offline: bool = False,
        cache_dir: Path | None = None,
    ) -> None:
        self._map_path: Path = Path(tempfile.gettempdir()) / "plan_map.html"
        self._radius_px = 18  # match QML card radius
        self._provider = provider if provider in self.TILESETS else "osm"
        self._offline = offline
        self._cache_dir = cache_dir or Path(tempfile.gettempdir()) / "tile-cache"
        self._cache_dir.mkdir(parents=True, exist_ok=True)

    @property
    def bridge_script(self) -> str:
        return self._BRIDGE_JS

    def set_provider(self, provider: str, *, offline: bool, cache_dir: Path | None = None) -> None:
        self._provider = provider if provider in self.TILESETS else "osm"
        self._offline = offline
        if cache_dir:
            self._cache_dir = cache_dir
            self._cache_dir.mkdir(parents=True, exist_ok=True)

    def _tile_layer(self) -> tuple[str, str]:
        if self._offline:
            url = f"file://{self._cache_dir.as_posix()}" + "/{z}/{x}/{y}.png"
            return url, f"Offline cache ({self._provider})"
        url, attr = self.TILESETS.get(self._provider, self.TILESETS["osm"])
        return url, attr

    def render_map(self, path: list[tuple[float, float]], token: int) -> Path:
        center = path[0] if path else (56.02, 92.9)
        tiles_url, attr = self._tile_layer()
        drone_pos = interpolate_path_point(path, getattr(deps, "debug_flight_progress", 0.0))

        fmap = folium.Map(
            center,
            zoom_start=13,
            control_scale=False,
            zoom_control=True,
            prefer_canvas=True,
            tiles=None,
            attributionControl=False,
        )

        folium.raster_layers.TileLayer(
            tiles=tiles_url,
            attr=attr,
            name=self._provider,
            overlay=False,
            control=False,
        ).add_to(fmap)

        Draw(
            export=False,
            draw_options={
                "polyline": {"shapeOptions": {"color": "#67d3ff"}},
                "polygon": False,
                "rectangle": False,
                "circle": False,
                "circlemarker": False,
                "marker": {"repeatMode": False},
            },
            edit_options={"edit": True, "remove": True},
        ).add_to(fmap)

        if path:
            folium.PolyLine(path, color="#67d3ff", weight=3).add_to(fmap)
            folium.CircleMarker(
                location=path[0],
                radius=7,
                color="#34d399",
                fill=True,
                fill_color="#34d399",
                weight=2,
                tooltip="Start",
            ).add_to(fmap)
            folium.CircleMarker(
                location=path[-1],
                radius=7,
                color="#f87171",
                fill=True,
                fill_color="#f87171",
                weight=2,
                tooltip="Finish",
            ).add_to(fmap)

        if drone_pos:
            folium.CircleMarker(
                location=drone_pos,
                radius=7,
                color="#7bc6ff",
                fill=True,
                fill_color="#7bc6ff",
                weight=3,
                tooltip="UAV (sim)",
            ).add_to(fmap)

        if deps.debug_target:
            lat = deps.debug_target.get("lat")
            lon = deps.debug_target.get("lon")
            if lat is not None and lon is not None:
                folium.CircleMarker(
                    location=(lat, lon),
                    radius=6,
                    color="red",
                    fill=True,
                    fill_color="red",
                    weight=2,
                ).add_to(fmap)

        if deps.debug_orbit_path:
            folium.PolyLine(
                locations=[(lat, lon) for lat, lon in deps.debug_orbit_path],
                color="orange",
                weight=2,
            ).add_to(fmap)

        fmap.get_root().header.add_child(
            folium.Element(
                f"""
<style>
.folium-map, .leaflet-container {{
    border-radius: {self._radius_px}px !important;
    overflow: hidden !important;
    background: transparent !important;
}}
.leaflet-pane, .leaflet-map-pane {{
    border-radius: {self._radius_px}px !important;
    overflow: hidden !important;
    background: transparent !important;
}}
.leaflet-control-attribution {{
    display: none !important;
}}
html, body {{
    background: transparent !important;
    margin: 0;
}}
</style>
"""
            )
        )

        fmap.save(self._map_path)
        return self._map_path


class StaticImageMapProvider:
    """Leaflet/Folium provider that renders a single georeferenced image overlay."""

    _BRIDGE_JS = FoliumMapProvider._BRIDGE_JS

    def __init__(self, image_path: str, bounds: MapBounds) -> None:
        self._map_path: Path = Path(tempfile.gettempdir()) / "plan_map.html"
        self._image_path = Path(image_path).expanduser().resolve()
        self._bounds = bounds
        self._radius_px = 18  # match QML card radius

    @property
    def bridge_script(self) -> str:
        return self._BRIDGE_JS

    def set_provider(self, provider: str, *, offline: bool, cache_dir: Path | None = None) -> None:
        return

    def render_map(self, path: list[tuple[float, float]], token: int) -> Path:
        lat_min = self._bounds.lat_min
        lon_min = self._bounds.lon_min
        lat_max = self._bounds.lat_max
        lon_max = self._bounds.lon_max
        center = ((lat_min + lat_max) / 2.0, (lon_min + lon_max) / 2.0)
        bounds = [[lat_min, lon_min], [lat_max, lon_max]]
        drone_pos = interpolate_path_point(path, getattr(deps, "debug_flight_progress", 0.0))

        fmap = folium.Map(
            center,
            zoom_start=13,
            control_scale=False,
            zoom_control=True,
            prefer_canvas=True,
            tiles=None,
            attributionControl=False,
        )

        folium.raster_layers.ImageOverlay(
            image=str(self._image_path),
            bounds=bounds,
            opacity=1.0,
            name="Static map",
            interactive=False,
            cross_origin=False,
            zindex=1,
        ).add_to(fmap)
        fmap.fit_bounds(bounds)

        Draw(
            export=False,
            draw_options={
                "polyline": {"shapeOptions": {"color": "#67d3ff"}},
                "polygon": False,
                "rectangle": False,
                "circle": False,
                "circlemarker": False,
                "marker": {"repeatMode": False},
            },
            edit_options={"edit": True, "remove": True},
        ).add_to(fmap)

        if path:
            folium.PolyLine(path, color="#67d3ff", weight=3).add_to(fmap)
            folium.CircleMarker(
                location=path[0],
                radius=7,
                color="#34d399",
                fill=True,
                fill_color="#34d399",
                weight=2,
                tooltip="Start",
            ).add_to(fmap)
            folium.CircleMarker(
                location=path[-1],
                radius=7,
                color="#f87171",
                fill=True,
                fill_color="#f87171",
                weight=2,
                tooltip="Finish",
            ).add_to(fmap)

        if drone_pos:
            folium.CircleMarker(
                location=drone_pos,
                radius=7,
                color="#7bc6ff",
                fill=True,
                fill_color="#7bc6ff",
                weight=3,
                tooltip="UAV (sim)",
            ).add_to(fmap)

        if deps.debug_target:
            lat = deps.debug_target.get("lat")
            lon = deps.debug_target.get("lon")
            if lat is not None and lon is not None:
                folium.CircleMarker(
                    location=(lat, lon),
                    radius=6,
                    color="red",
                    fill=True,
                    fill_color="red",
                    weight=2,
                ).add_to(fmap)

        if deps.debug_orbit_path:
            folium.PolyLine(
                locations=[(lat, lon) for lat, lon in deps.debug_orbit_path],
                color="orange",
                weight=2,
            ).add_to(fmap)

        fmap.get_root().header.add_child(
            folium.Element(
                f"""
<style>
.folium-map, .leaflet-container {{
    border-radius: {self._radius_px}px !important;
    overflow: hidden !important;
    background: transparent !important;
}}
.leaflet-pane, .leaflet-map-pane {{
    border-radius: {self._radius_px}px !important;
    overflow: hidden !important;
    background: transparent !important;
}}
.leaflet-control-attribution {{
    display: none !important;
}}
html, body {{
    background: transparent !important;
    margin: 0;
}}
</style>
"""
            )
        )

        fmap.save(self._map_path)
        return self._map_path


class UnrealMapProvider:
    """
    Placeholder for Unreal/remote map integration.
    """

    def __init__(self, url: str) -> None:
        self._url = url

    @property
    def bridge_script(self) -> str:
        return ""

    def set_provider(self, provider: str, *, offline: bool, cache_dir: Path | None = None) -> None:
        raise NotImplementedError

    def render_map(self, path: list[tuple[float, float]], token: int) -> Path:
        raise NotImplementedError("Unreal map provider is not implemented yet")
