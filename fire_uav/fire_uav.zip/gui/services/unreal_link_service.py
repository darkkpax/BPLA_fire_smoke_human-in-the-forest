from __future__ import annotations

import json
import logging
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Callable

import httpx
from PySide6.QtCore import QObject, QThread, QTimer, Signal
from PySide6.QtGui import QImage

from fire_uav.core.protocol import MapBounds, TelemetryMessage
from fire_uav.core.telemetry import telemetry_sample_from_message
from fire_uav.services.bus import Event, bus

log = logging.getLogger(__name__)

try:
    import av  # type: ignore
except Exception:  # noqa: BLE001
    av = None


class _H264StreamWorker(QThread):
    frameReady = Signal(QImage)
    statusChanged = Signal(str)

    def __init__(
        self,
        *,
        url: str,
        target_fps: float,
        reconnect_s: float,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self._url = url
        self._target_interval = 1.0 / target_fps if target_fps > 0 else 0.0
        self._reconnect_s = max(0.2, reconnect_s)
        self._running = True
        self._enabled = True
        self._last_status: str | None = None
        self._probe_client = httpx.Client(timeout=2.0)

    def stop(self) -> None:
        self._running = False

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = bool(enabled)

    def update_url(self, url: str) -> None:
        self._url = url

    def run(self) -> None:
        last_emit = 0.0
        while self._running:
            if not self._enabled:
                self._set_status("paused")
                time.sleep(0.2)
                continue

            container = None
            try:
                container = av.open(self._url, format="mpegts")
                self._set_status("streaming")
                for frame in container.decode(video=0):
                    if not self._running or not self._enabled:
                        break
                    now = time.monotonic()
                    if self._target_interval and (now - last_emit) < self._target_interval:
                        continue
                    arr = frame.to_ndarray(format="rgb24")
                    h, w, _ = arr.shape
                    img = QImage(arr.data, w, h, 3 * w, QImage.Format.Format_RGB888).copy()
                    self.frameReady.emit(img)
                    last_emit = now
            except Exception as exc:  # noqa: BLE001
                status = self._probe_status()
                self._set_status(status)
                if status == "disconnected":
                    log.debug("Unreal H264 stream error: %s", exc)
            finally:
                if container is not None:
                    try:
                        container.close()
                    except Exception:  # noqa: BLE001
                        pass
            time.sleep(self._reconnect_s)

        try:
            self._probe_client.close()
        except Exception:  # noqa: BLE001
            pass

    def _set_status(self, status: str) -> None:
        if status == self._last_status:
            return
        self._last_status = status
        self.statusChanged.emit(status)

    def _probe_status(self) -> str:
        try:
            with self._probe_client.stream("GET", self._url) as resp:
                if resp.status_code == 503:
                    return "waiting_for_route"
                if resp.status_code >= 400:
                    return "disconnected"
        except Exception:
            return "disconnected"
        return "disconnected"


@dataclass
class _Backoff:
    base_s: float = 1.0
    max_s: float = 5.0
    current_s: float = 1.0
    next_ts: float = 0.0

    def allow(self) -> bool:
        return time.monotonic() >= self.next_ts

    def success(self) -> None:
        self.current_s = self.base_s
        self.next_ts = 0.0

    def fail(self) -> None:
        self.current_s = min(self.max_s, self.current_s * 2.0)
        self.next_ts = time.monotonic() + self.current_s


class UnrealLinkService(QObject):
    def __init__(
        self,
        *,
        base_url: str = "http://127.0.0.1:9000",
        uav_id: str = "sim",
        telemetry_hz: float = 6.0,
        detections_hz: float = 2.0,
        camera_hz: float = 6.0,
        camera_mode: str = "jpeg_snapshots",
        video_endpoint: str = "/sim/v1/video.ts",
        video_target_fps: float = 20.0,
        video_reconnect_s: float = 1.0,
        on_telemetry: Callable[[object], None] | None = None,
        on_detections: Callable[[object, list[dict[str, Any]]], None] | None = None,
        on_camera_frame: Callable[[QImage], None] | None = None,
        on_link_status: Callable[[str], None] | None = None,
        on_camera_status: Callable[[str], None] | None = None,
        on_map_ready: Callable[[str, MapBounds], None] | None = None,
    ) -> None:
        super().__init__()
        self.base_url = base_url.rstrip("/")
        self.uav_id = uav_id
        self._on_telemetry = on_telemetry
        self._on_detections = on_detections
        self._on_camera_frame = on_camera_frame
        self._on_link_status = on_link_status
        self._on_camera_status = on_camera_status
        self._on_map_ready = on_map_ready
        self._client = httpx.Client(timeout=2.5)

        self._telemetry_timer = QTimer(self)
        self._telemetry_timer.setInterval(max(50, int(1000 / max(1.0, telemetry_hz))))
        self._telemetry_timer.timeout.connect(self._poll_telemetry)

        self._detections_timer = QTimer(self)
        self._detections_timer.setInterval(max(200, int(1000 / max(0.5, detections_hz))))
        self._detections_timer.timeout.connect(self._poll_detections)

        self._camera_timer = QTimer(self)
        self._camera_timer.setInterval(max(50, int(1000 / max(1.0, camera_hz))))
        self._camera_timer.timeout.connect(self._poll_camera)

        self._camera_mode = camera_mode
        self._video_endpoint = video_endpoint
        self._video_target_fps = video_target_fps
        self._video_reconnect_s = video_reconnect_s
        self._camera_enabled = True
        self._stream_worker: _H264StreamWorker | None = None

        self._map_timer = QTimer(self)
        self._map_timer.setSingleShot(True)
        self._map_timer.timeout.connect(self._poll_map)

        self._telemetry_backoff = _Backoff()
        self._detections_backoff = _Backoff()
        self._camera_backoff = _Backoff()
        self._map_backoff = _Backoff(base_s=2.0, max_s=10.0)

        self._last_status: str | None = None
        self._last_camera_status: str | None = None
        self._last_camera_error = False
        self._map_ready = False
        self._object_emit_ts: dict[str, float] = {}

    def start(self) -> None:
        self._telemetry_timer.start()
        self._detections_timer.start()
        self._start_camera_pipeline()
        self._map_timer.start(0)

    def stop(self) -> None:
        self._telemetry_timer.stop()
        self._detections_timer.stop()
        self._camera_timer.stop()
        self._map_timer.stop()
        self._stop_stream_worker()
        self._client.close()

    def set_camera_enabled(self, enabled: bool) -> None:
        self._camera_enabled = bool(enabled)
        if self._camera_mode == "h264_stream":
            if self._stream_worker is not None:
                self._stream_worker.set_enabled(self._camera_enabled)
        else:
            if self._camera_enabled:
                if not self._camera_timer.isActive():
                    self._camera_timer.start()
            else:
                self._camera_timer.stop()

    def set_camera_mode(self, mode: str) -> None:
        normalized = str(mode or "").strip().lower()
        if normalized not in ("jpeg_snapshots", "h264_stream"):
            return
        if normalized == self._camera_mode:
            return
        self._camera_mode = normalized
        self._start_camera_pipeline()

    # ----------------------------- internal setup ----------------------------- #
    def _start_camera_pipeline(self) -> None:
        self._camera_timer.stop()
        self._stop_stream_worker()
        if self._camera_mode == "h264_stream":
            if av is None:
                log.warning("PyAV not available; falling back to JPEG snapshots")
                self._camera_mode = "jpeg_snapshots"
            else:
                url = f"{self.base_url}{self._video_endpoint}"
                self._stream_worker = _H264StreamWorker(
                    url=url,
                    target_fps=self._video_target_fps,
                    reconnect_s=self._video_reconnect_s,
                )
                self._stream_worker.frameReady.connect(self._handle_stream_frame)
                self._stream_worker.statusChanged.connect(self._handle_stream_status)
                self._stream_worker.set_enabled(self._camera_enabled)
                self._stream_worker.start()
                return
        if self._camera_enabled:
            self._camera_timer.start()

    def _stop_stream_worker(self) -> None:
        if self._stream_worker is None:
            return
        try:
            self._stream_worker.stop()
            self._stream_worker.wait(1500)
        except Exception:  # noqa: BLE001
            pass
        self._stream_worker = None

    def _handle_stream_frame(self, img: QImage) -> None:
        if self._on_camera_frame:
            self._on_camera_frame(img)
        self._set_camera_status("streaming")

    def _handle_stream_status(self, status: str) -> None:
        self._set_camera_status(status)

    # ----------------------------- public API ----------------------------- #
    def send_route(self, route: dict) -> bool:
        try:
            resp = self._client.post(f"{self.base_url}/sim/v1/route", json=route)
            resp.raise_for_status()
            return True
        except Exception as exc:  # noqa: BLE001
            log.warning("Unreal route send failed: %s", exc)
            return False

    def send_command(self, command: str, payload: dict | None = None) -> bool:
        body = {"uav_id": self.uav_id, "command": str(command), "payload": payload or {}}
        try:
            resp = self._client.post(f"{self.base_url}/sim/v1/command", json=body)
            resp.raise_for_status()
            return True
        except Exception as exc:  # noqa: BLE001
            log.warning("Unreal command send failed: %s", exc)
            return False

    # ----------------------------- polling ----------------------------- #
    def _poll_map(self) -> None:
        if self._map_ready:
            return
        if not self._map_backoff.allow():
            self._map_timer.start(int(self._map_backoff.current_s * 1000))
            return
        try:
            info = self._client.get(f"{self.base_url}/sim/v1/map_info").json()
            bounds = self._extract_bounds(info)
            if bounds is None:
                log.error("Unreal map_info invalid or missing bounds: %s", json.dumps(info))
                self._map_backoff.fail()
                self._map_timer.start(int(self._map_backoff.current_s * 1000))
                return
            img_resp = self._client.get(f"{self.base_url}/sim/v1/map.png", timeout=5.0)
            img_resp.raise_for_status()
            cache_dir = Path(tempfile.gettempdir()) / "fire_uav"
            cache_dir.mkdir(parents=True, exist_ok=True)
            map_path = cache_dir / "unreal_map.png"
            map_path.write_bytes(img_resp.content)
            self._map_ready = True
            self._map_backoff.success()
            if self._on_map_ready:
                self._on_map_ready(str(map_path), bounds)
            log.info("Unreal map snapshot loaded from %s", map_path)
            return
        except Exception as exc:  # noqa: BLE001
            if not self._map_ready:
                log.debug("Unreal map fetch failed: %s", exc)
            self._map_backoff.fail()
            self._map_timer.start(int(self._map_backoff.current_s * 1000))

    def _poll_telemetry(self) -> None:
        if not self._telemetry_backoff.allow():
            return
        url = f"{self.base_url}/sim/v1/telemetry"
        try:
            resp = self._client.get(url)
            if resp.status_code == 503:
                self._set_status("waiting_for_route")
                self._telemetry_backoff.success()
                return
            resp.raise_for_status()
            payload = resp.json()
            msg = TelemetryMessage(**payload)
            sample = telemetry_sample_from_message(msg)
            sample.source = msg.uav_id
            self._telemetry_backoff.success()
            self._set_status("connected")
            if self._on_telemetry:
                self._on_telemetry(sample)
        except Exception as exc:  # noqa: BLE001
            self._set_status("disconnected")
            self._telemetry_backoff.fail()
            if self._telemetry_backoff.current_s >= 4.0:
                log.debug("Unreal telemetry poll failed: %s", exc)

    def _poll_detections(self) -> None:
        if not self._detections_backoff.allow():
            return
        url = f"{self.base_url}/sim/v1/detections"
        try:
            resp = self._client.get(url)
            if resp.status_code == 404:
                self._detections_backoff.success()
                return
            resp.raise_for_status()
            payload = resp.json()
            batch, objects = self._normalize_detections(payload)
            self._detections_backoff.success()
            if self._on_detections:
                self._on_detections(batch, objects)
        except Exception as exc:  # noqa: BLE001
            self._detections_backoff.fail()
            if self._detections_backoff.current_s >= 4.0:
                log.debug("Unreal detections poll failed: %s", exc)

    def _poll_camera(self) -> None:
        if not self._camera_enabled:
            return
        if not self._camera_backoff.allow():
            return
        for suffix in ("camera.jpg", "camera.png"):
            try:
                resp = self._client.get(f"{self.base_url}/sim/v1/{suffix}")
                if resp.status_code == 503:
                    self._camera_backoff.success()
                    self._set_camera_status("waiting_for_route")
                    return
                if resp.status_code == 404:
                    continue
                resp.raise_for_status()
                img = QImage.fromData(resp.content)
                if img.isNull():
                    raise RuntimeError("Invalid image data")
                self._camera_backoff.success()
                if self._last_camera_error:
                    self._last_camera_error = False
                    log.info("Unreal camera stream recovered")
                self._set_camera_status("streaming")
                if self._on_camera_frame:
                    self._on_camera_frame(img)
                return
            except Exception as exc:  # noqa: BLE001
                self._camera_backoff.fail()
                self._set_camera_status("disconnected")
                if not self._last_camera_error:
                    log.debug("Unreal camera poll failed: %s", exc)
                    self._last_camera_error = True
                return

    # ----------------------------- helpers ----------------------------- #
    def _set_status(self, status: str) -> None:
        if status == self._last_status:
            return
        self._last_status = status
        if self._on_link_status:
            self._on_link_status(status)

    def _set_camera_status(self, status: str) -> None:
        if status == self._last_camera_status:
            return
        self._last_camera_status = status
        if self._on_camera_status:
            self._on_camera_status(status)

    @staticmethod
    def _extract_bounds(payload: dict) -> MapBounds | None:
        if not isinstance(payload, dict):
            return None
        raw = payload.get("bounds") if isinstance(payload.get("bounds"), dict) else None
        for source in (raw, payload):
            if not isinstance(source, dict):
                continue
            bounds = UnrealLinkService._parse_bounds_dict(source)
            if bounds is not None:
                return bounds
        return None

    @staticmethod
    def _parse_bounds_dict(source: dict[str, Any]) -> MapBounds | None:
        key_map = {
            "lat_min": ("lat_min", "latMin"),
            "lon_min": ("lon_min", "lonMin"),
            "lat_max": ("lat_max", "latMax"),
            "lon_max": ("lon_max", "lonMax"),
        }
        values: dict[str, Any] = {}
        for target, aliases in key_map.items():
            for key in aliases:
                if key in source:
                    values[target] = source[key]
                    break
        if len(values) != len(key_map):
            return None
        try:
            return MapBounds(
                lat_min=float(values["lat_min"]),
                lon_min=float(values["lon_min"]),
                lat_max=float(values["lat_max"]),
                lon_max=float(values["lon_max"]),
            )
        except (TypeError, ValueError):
            return None

    def _normalize_detections(self, payload: Any) -> tuple[object, list[dict[str, Any]]]:
        items: list[Any] = []
        if isinstance(payload, dict):
            items = payload.get("detections") or payload.get("objects") or []
        elif isinstance(payload, list):
            items = payload
        det_list = []
        objects: list[dict[str, Any]] = []
        now = time.monotonic()
        for idx, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            bbox = item.get("bbox")
            if bbox is None and all(k in item for k in ("x1", "y1", "x2", "y2")):
                bbox = [item.get("x1"), item.get("y1"), item.get("x2"), item.get("y2")]
            det = SimpleNamespace(
                bbox=tuple(bbox) if bbox else None,
                x1=item.get("x1"),
                y1=item.get("y1"),
                x2=item.get("x2"),
                y2=item.get("y2"),
                confidence=item.get("confidence", item.get("score", 0.0)),
                class_id=item.get("class_id", item.get("cls", -1)),
            )
            det_list.append(det)
            if "lat" in item and "lon" in item:
                object_id = str(item.get("object_id") or f"unreal-{idx}")
                last_ts = self._object_emit_ts.get(object_id, 0.0)
                if now - last_ts < 5.0:
                    continue
                self._object_emit_ts[object_id] = now
                obj = {
                    "object_id": object_id,
                    "class_id": int(item.get("class_id", item.get("cls", -1))),
                    "confidence": float(item.get("confidence", item.get("score", 0.0))),
                    "lat": float(item.get("lat")),
                    "lon": float(item.get("lon")),
                    "track_id": item.get("track_id"),
                    "timestamp": item.get("timestamp"),
                }
                objects.append(obj)
        batch = SimpleNamespace(detections=det_list)
        return batch, objects


__all__ = ["UnrealLinkService"]
